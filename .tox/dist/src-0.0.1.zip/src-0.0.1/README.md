create env
```bash
conda create -n WineQuality python=3.7 -y
```

acitvate env
```bash
conda activate WineQuality
```
create a req file
install the req
```bash
pip install -r requirements.txt
```